# NeoAlbum - WordPress 3D Book Album Plugin

A complete WordPress plugin that creates stunning 3D book-style album sliders with page flip effects.

## Features

- 📚 **Realistic 3D Book Flip Effect**: Natural page turning animation with proper easing and shadows
- 🔒 **Image Locking**: Prevent users from saving or clicking images
- 🔐 **Password Protection**: Restrict album access with a password
- 🎨 **Customizable Settings**: Adjust dimensions, animation speed, and more
- 📱 **Responsive Design**: Works on all screen sizes
- 🔊 **Authentic Page Flip Sound**: Realistic paper flip sound using WebAudio API
- 📄 **A4 Size Default**: Preconfigured for A4 portrait orientation
- 👆 **Dual Page Display**: Two images side-by-side like an open book
- ⌨️ **Keyboard Navigation**: Use arrow keys to turn pages
- 📝 **Shortcode Support**: Easy integration with any post or page
- 🖼️ **Fullscreen Mode**: View albums in immersive fullscreen
- 🔍 **Zoom Capability**: Zoom in and out on pages with buttons or double-click
- 📷 **Enhanced Screenshot Prevention**: Blocks PrintScreen, context menu, and hides content on window blur
- 🎨 **Book Frame Styling**: Customizable book border color
- ↔️ **Adjustable Centering**: Fine-tune horizontal position
- ⚡ **Settings Apply Everywhere**: Changes affect all existing albums immediately

## Installation

1. Upload the `neoalbum` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Navigate to the 'NeoAlbum' menu in your WordPress admin

## Usage

### Creating an Album

1. Go to **NeoAlbum > Albums** in your WordPress admin
2. Enter an **Album Name**
3. Click **Select Images** and choose your images
   - Images should be named sequentially (e.g., 01.jpg, 02.jpg, 03.jpg) for proper ordering
4. (Optional) Set a **Password** to restrict access
5. (Optional) Check **Lock Images** to prevent saving/clicking
6. Click **Create Album**
7. Copy the generated shortcode and paste it into any post or page

### Settings

Go to **NeoAlbum > Settings** to configure:
- **Default Width/Height**: Set the album dimensions (default: 800x1132px for A4 ratio)
- **Page Flip Sound**: Enable/disable audio effects
- **Animation Speed**: Adjust page turn speed (100-3000ms)
- **Default Orientation**: Portrait or Landscape
- **Prevent Screenshots**: Block PrintScreen and context menu
- **Book Frame Color**: Customize the book border color
- **Centering Offset**: Fine-tune horizontal position

## Shortcode Usage

```
[neoalbum id="neoalbum_xxxxx"]
```

Replace `neoalbum_xxxxx` with your actual album ID (found in the Albums list).

## Keyboard Shortcuts

- **← / →**: Previous/Next page
- **F**: Toggle fullscreen
- **+ / -**: Zoom in/out
- **Esc**: Exit fullscreen

## Frequently Asked Questions

### How are images ordered?
Images are automatically sorted by numeric filename (01.jpg, 02.jpg, etc.).

### Can I change the album size for a specific shortcode?
Currently, size settings are global (applied to all albums). Use the Settings page to adjust.

### Is the password secure?
Passwords are stored in plain text in the database (for simplicity). Do not use sensitive passwords.

### Is screenshot prevention 100% effective?
No. Complete screenshot prevention is not possible in web browsers. This feature provides basic protection by blocking common methods, but determined users can still find ways to capture the content.

### How do I add a custom page flip sound?
Download a page flip sound effect (MP3 format) and save it as `page-flip.mp3` in the `assets/audio/` directory. The plugin will automatically use it.

## Requirements

- WordPress 5.0 or higher
- PHP 7.0 or higher
- Modern web browser with JavaScript enabled

## Changelog

### 1.1.0
- Added fullscreen mode
- Added zoom functionality (buttons and double-click)
- Added screenshot prevention
- Added customizable book frame color
- Added adjustable centering offset
- Improved sound system with audio file support
- Added keyboard shortcuts
- Enhanced UI with new controls

### 1.0.0
- Initial release
- Complete 3D book flip functionality
- Password protection
- Image locking
- Admin interface
- Settings page
- Shortcode support
