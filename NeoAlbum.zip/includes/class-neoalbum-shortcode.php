<?php
if (!defined('ABSPATH')) {
    exit;
}

class NeoAlbum_Shortcode {
    private static $instance = null;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->init();
    }

    private function init() {
        add_shortcode('neoalbum', array($this, 'render_shortcode'));
        add_action('wp_ajax_neoalbum_verify_password', array($this, 'verify_password'));
        add_action('wp_ajax_nopriv_neoalbum_verify_password', array($this, 'verify_password'));
    }

    public function render_shortcode($atts) {
        $atts = shortcode_atts(array(
            'id' => ''
        ), $atts, 'neoalbum');

        if (empty($atts['id'])) {
            return '<p>' . esc_html__('Invalid album ID', 'neoalbum') . '</p>';
        }

        $albums = get_option('neoalbum_albums', array());
        if (!isset($albums[$atts['id']])) {
            return '<p>' . esc_html__('Album not found', 'neoalbum') . '</p>';
        }

        $album = $albums[$atts['id']];
        $settings = get_option('neoalbum_settings', array());
        $width = isset($settings['width']) ? $settings['width'] : '800px';
        $height = isset($settings['height']) ? $settings['height'] : '1132px';
        $sound_enabled = isset($settings['sound']) ? $settings['sound'] : true;
        $speed = isset($settings['speed']) ? $settings['speed'] : 1000;
        $orientation = isset($settings['orientation']) ? $settings['orientation'] : 'portrait';
        $has_password = !empty($album['password']);
        $lock_images = isset($album['lock_images']) ? $album['lock_images'] : false;
        $prevent_screenshot = isset($settings['prevent_screenshot']) ? $settings['prevent_screenshot'] : false;
        $book_frame_color = isset($settings['book_frame_color']) ? $settings['book_frame_color'] : '#8B4513';
        $centering_offset = isset($settings['centering_offset']) ? $settings['centering_offset'] : 0;

        wp_enqueue_style('neoalbum-style');
        wp_enqueue_script('neoalbum-script');
        wp_localize_script('neoalbum-script', 'NEOALBUM_PLUGIN_URL', NEOALBUM_PLUGIN_URL);

        ob_start();
        ?>
        <div class="neoalbum-container" 
             data-album-id="<?php echo esc_attr($atts['id']); ?>"
             data-width="<?php echo esc_attr($width); ?>"
             data-height="<?php echo esc_attr($height); ?>"
             data-sound="<?php echo esc_attr($sound_enabled); ?>"
             data-speed="<?php echo esc_attr($speed); ?>"
             data-orientation="<?php echo esc_attr($orientation); ?>"
             data-has-password="<?php echo esc_attr($has_password ? '1' : '0'); ?>"
             data-lock-images="<?php echo esc_attr($lock_images ? '1' : '0'); ?>"
             data-prevent-screenshot="<?php echo esc_attr($prevent_screenshot ? '1' : '0'); ?>"
             style="margin-left: <?php echo esc_attr($centering_offset); ?>px;">
            
            <?php if ($has_password): ?>
                <div class="neoalbum-password-form">
                    <h3><?php echo esc_html__('This album is password protected', 'neoalbum'); ?></h3>
                    <p><?php echo esc_html__('Please enter the password to view:', 'neoalbum'); ?></p>
                    <input type="password" class="neoalbum-password-input" placeholder="<?php echo esc_html__('Enter password', 'neoalbum'); ?>" />
                    <button class="button neoalbum-submit-password"><?php echo esc_html__('View Album', 'neoalbum'); ?></button>
                    <p class="neoalbum-password-error" style="display:none; color:red;"><?php echo esc_html__('Incorrect password', 'neoalbum'); ?></p>
                </div>
            <?php endif; ?>

            <div class="neoalbum-book-wrapper" <?php echo $has_password ? 'style="display:none;"' : ''; ?>>
                <div class="neoalbum-book" style="border-color: <?php echo esc_attr($book_frame_color); ?>;">
                    <div class="neoalbum-page-container left-container">
                        <div class="neoalbum-page left-page">
                            <div class="neoalbum-page-content">
                                <img src="" alt="" class="neoalbum-page-image">
                            </div>
                        </div>
                    </div>
                    <div class="neoalbum-page-container right-container">
                        <div class="neoalbum-page right-page">
                            <div class="neoalbum-page-content">
                                <img src="" alt="" class="neoalbum-page-image">
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="neoalbum-controls">
                    <button class="neoalbum-prev-btn" <?php echo $lock_images ? 'disabled' : ''; ?>>
                        <?php echo esc_html__('Previous', 'neoalbum'); ?>
                    </button>
                    <button class="neoalbum-zoom-out-btn">
                        <?php echo esc_html__('Zoom Out', 'neoalbum'); ?>
                    </button>
                    <span class="neoalbum-page-indicator"></span>
                    <button class="neoalbum-zoom-in-btn">
                        <?php echo esc_html__('Zoom In', 'neoalbum'); ?>
                    </button>
                    <button class="neoalbum-next-btn" <?php echo $lock_images ? 'disabled' : ''; ?>>
                        <?php echo esc_html__('Next', 'neoalbum'); ?>
                    </button>
                    <button class="neoalbum-fullscreen-btn">
                        <?php echo esc_html__('Fullscreen', 'neoalbum'); ?>
                    </button>
                </div>
            </div>

            <div class="neoalbum-images-data" style="display:none;">
                <?php foreach ($album['images'] as $image_url): ?>
                    <span class="neoalbum-image-url" data-url="<?php echo esc_url($image_url); ?>"></span>
                <?php endforeach; ?>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    public function verify_password() {
        check_ajax_referer('neoalbum_nonce', 'nonce');

        $album_id = sanitize_text_field($_POST['album_id']);
        $password = sanitize_text_field($_POST['password']);

        $albums = get_option('neoalbum_albums', array());

        if (isset($albums[$album_id]) && $albums[$album_id]['password'] === $password) {
            wp_send_json_success(array('valid' => true));
        }

        wp_send_json_error(array('valid' => false));
    }
}

NeoAlbum_Shortcode::get_instance();
