<?php
if (!defined('ABSPATH')) {
    exit;
}

class NeoAlbum_Admin {
    private static $instance = null;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->init();
    }

    private function init() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('wp_ajax_neoalbum_save_album', array($this, 'save_album'));
        add_action('wp_ajax_neoalbum_get_albums', array($this, 'get_albums'));
        add_action('wp_ajax_neoalbum_delete_album', array($this, 'delete_album'));
    }

    public function register_settings() {
        register_setting(
            'neoalbum_settings_group',
            'neoalbum_settings'
        );
    }

    public function add_admin_menu() {
        add_menu_page(
            'NeoAlbum',
            'NeoAlbum',
            'manage_options',
            'neoalbum',
            array($this, 'render_admin_page'),
            'dashicons-book-alt',
            30
        );

        add_submenu_page(
            'neoalbum',
            'Albums',
            'Albums',
            'manage_options',
            'neoalbum',
            array($this, 'render_admin_page')
        );

        add_submenu_page(
            'neoalbum',
            'Settings',
            'Settings',
            'manage_options',
            'neoalbum-settings',
            array($this, 'render_settings_page')
        );
    }

    public function enqueue_admin_scripts($hook) {
        if ('toplevel_page_neoalbum' !== $hook && 'neoalbum_page_neoalbum-settings' !== $hook) {
            return;
        }

        wp_enqueue_style('neoalbum-admin-style', NEOALBUM_PLUGIN_URL . 'assets/css/admin.css', array(), NEOALBUM_VERSION);
        wp_enqueue_script('neoalbum-admin-script', NEOALBUM_PLUGIN_URL . 'assets/js/admin.js', array('jquery'), NEOALBUM_VERSION, true);
        wp_enqueue_media();
        wp_localize_script('neoalbum-admin-script', 'neoalbum_admin', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('neoalbum_admin_nonce'),
            'strings' => array(
                'select_images' => __('Select Images', 'neoalbum'),
                'use_these_images' => __('Use These Images', 'neoalbum'),
                'delete_confirm' => __('Are you sure you want to delete this album?', 'neoalbum')
            )
        ));
    }

    public function render_admin_page() {
        ?>
        <div class="wrap neoalbum-admin">
            <h1><?php echo esc_html__('NeoAlbum - Albums', 'neoalbum'); ?></h1>
            
            <div class="neoalbum-create-album">
                <h2><?php echo esc_html__('Create New Album', 'neoalbum'); ?></h2>
                <div class="neoalbum-form">
                    <div class="form-field">
                        <label for="neoalbum-name"><?php echo esc_html__('Album Name', 'neoalbum'); ?></label>
                        <input type="text" id="neoalbum-name" class="regular-text" />
                    </div>
                    <div class="form-field">
                        <label><?php echo esc_html__('Album Images', 'neoalbum'); ?></label>
                        <button type="button" class="button button-primary neoalbum-upload-btn">
                            <?php echo esc_html__('Select Images', 'neoalbum'); ?>
                        </button>
                        <div class="neoalbum-images-preview"></div>
                    </div>
                    <div class="form-field">
                        <label for="neoalbum-password"><?php echo esc_html__('Password (Optional)', 'neoalbum'); ?></label>
                        <input type="text" id="neoalbum-password" class="regular-text" placeholder="<?php echo esc_html__('Leave empty for no password', 'neoalbum'); ?>" />
                    </div>
                    <div class="form-field">
                        <label for="neoalbum-lock-images">
                            <input type="checkbox" id="neoalbum-lock-images" />
                            <?php echo esc_html__('Lock Images (Prevent Saving/Clicking)', 'neoalbum'); ?>
                        </label>
                    </div>
                    <button type="button" class="button button-primary neoalbum-save-btn">
                        <?php echo esc_html__('Create Album', 'neoalbum'); ?>
                    </button>
                </div>
            </div>

            <div class="neoalbum-albums-list">
                <h2><?php echo esc_html__('Your Albums', 'neoalbum'); ?></h2>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th><?php echo esc_html__('Album Name', 'neoalbum'); ?></th>
                            <th><?php echo esc_html__('Images', 'neoalbum'); ?></th>
                            <th><?php echo esc_html__('Shortcode', 'neoalbum'); ?></th>
                            <th><?php echo esc_html__('Actions', 'neoalbum'); ?></th>
                        </tr>
                    </thead>
                    <tbody id="neoalbum-albums-tbody"></tbody>
                </table>
            </div>
        </div>
        <?php
    }

    public function render_settings_page() {
        $options = get_option('neoalbum_settings', array());
        ?>
        <div class="wrap neoalbum-admin">
            <h1><?php echo esc_html__('NeoAlbum - Settings', 'neoalbum'); ?></h1>
            
            <form method="post" action="options.php">
                <?php
                settings_fields('neoalbum_settings_group');
                do_settings_sections('neoalbum_settings');
                ?>
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row"><?php echo esc_html__('Default Width', 'neoalbum'); ?></th>
                        <td>
                            <input type="text" name="neoalbum_settings[width]" value="<?php echo isset($options['width']) ? esc_attr($options['width']) : '800px'; ?>" />
                            <p class="description"><?php echo esc_html__('Default width of the album (e.g., 800px, 100%)', 'neoalbum'); ?></p>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row"><?php echo esc_html__('Default Height', 'neoalbum'); ?></th>
                        <td>
                            <input type="text" name="neoalbum_settings[height]" value="<?php echo isset($options['height']) ? esc_attr($options['height']) : '1132px'; ?>" />
                            <p class="description"><?php echo esc_html__('Default height of the album (A4 aspect ratio: ~1132px for 800px width)', 'neoalbum'); ?></p>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row"><?php echo esc_html__('Page Flip Sound', 'neoalbum'); ?></th>
                        <td>
                            <select name="neoalbum_settings[sound]">
                                <option value="1" <?php selected(isset($options['sound']) ? $options['sound'] : 1, 1); ?>><?php echo esc_html__('Enabled', 'neoalbum'); ?></option>
                                <option value="0" <?php selected(isset($options['sound']) ? $options['sound'] : 1, 0); ?>><?php echo esc_html__('Disabled', 'neoalbum'); ?></option>
                            </select>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row"><?php echo esc_html__('Animation Speed', 'neoalbum'); ?></th>
                        <td>
                            <input type="number" name="neoalbum_settings[speed]" value="<?php echo isset($options['speed']) ? esc_attr($options['speed']) : 1000; ?>" min="100" max="3000" />
                            <p class="description"><?php echo esc_html__('Page flip animation speed in milliseconds', 'neoalbum'); ?></p>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row"><?php echo esc_html__('Default Orientation', 'neoalbum'); ?></th>
                        <td>
                            <select name="neoalbum_settings[orientation]">
                                <option value="portrait" <?php selected(isset($options['orientation']) ? $options['orientation'] : 'portrait', 'portrait'); ?>><?php echo esc_html__('Portrait (Default)', 'neoalbum'); ?></option>
                                <option value="landscape" <?php selected(isset($options['orientation']) ? $options['orientation'] : 'portrait', 'landscape'); ?>><?php echo esc_html__('Landscape', 'neoalbum'); ?></option>
                            </select>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row"><?php echo esc_html__('Prevent Screenshots', 'neoalbum'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="neoalbum_settings[prevent_screenshot]" value="1" <?php checked(isset($options['prevent_screenshot']) ? $options['prevent_screenshot'] : false, true); ?> />
                                <?php echo esc_html__('Enable screenshot prevention (blocks PrintScreen and context menu)', 'neoalbum'); ?>
                            </label>
                            <p class="description"><?php echo esc_html__('Note: Complete screenshot prevention is not possible in browsers, this provides basic protection.', 'neoalbum'); ?></p>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row"><?php echo esc_html__('Book Frame Color', 'neoalbum'); ?></th>
                        <td>
                            <input type="color" name="neoalbum_settings[book_frame_color]" value="<?php echo isset($options['book_frame_color']) ? esc_attr($options['book_frame_color']) : '#8B4513'; ?>" />
                            <p class="description"><?php echo esc_html__('Choose the color for the book frame/border', 'neoalbum'); ?></p>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row"><?php echo esc_html__('Centering Offset', 'neoalbum'); ?></th>
                        <td>
                            <input type="number" name="neoalbum_settings[centering_offset]" value="<?php echo isset($options['centering_offset']) ? esc_attr($options['centering_offset']) : 0; ?>" min="-500" max="500" />
                            <p class="description"><?php echo esc_html__('Adjust horizontal centering (pixels, negative = left, positive = right)', 'neoalbum'); ?></p>
                        </td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }

    public function save_album() {
        check_ajax_referer('neoalbum_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Unauthorized', 'neoalbum')));
        }

        $album_data = array(
            'name' => sanitize_text_field($_POST['name']),
            'images' => isset($_POST['images']) ? array_map('esc_url', $_POST['images']) : array(),
            'password' => sanitize_text_field($_POST['password']),
            'lock_images' => isset($_POST['lock_images']) ? (bool)$_POST['lock_images'] : false,
            'created_at' => current_time('mysql')
        );

        $albums = get_option('neoalbum_albums', array());
        $album_id = uniqid('neoalbum_');
        $albums[$album_id] = $album_data;
        update_option('neoalbum_albums', $albums);

        wp_send_json_success(array(
            'message' => __('Album created successfully!', 'neoalbum'),
            'album_id' => $album_id,
            'shortcode' => '[neoalbum id="' . $album_id . '"]'
        ));
    }

    public function get_albums() {
        check_ajax_referer('neoalbum_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Unauthorized', 'neoalbum')));
        }

        $albums = get_option('neoalbum_albums', array());
        $formatted_albums = array();

        foreach ($albums as $id => $album) {
            $formatted_albums[] = array(
                'id' => $id,
                'name' => $album['name'],
                'image_count' => count($album['images']),
                'shortcode' => '[neoalbum id="' . $id . '"]'
            );
        }

        wp_send_json_success(array('albums' => $formatted_albums));
    }

    public function delete_album() {
        check_ajax_referer('neoalbum_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Unauthorized', 'neoalbum')));
        }

        $album_id = sanitize_text_field($_POST['album_id']);
        $albums = get_option('neoalbum_albums', array());

        if (isset($albums[$album_id])) {
            unset($albums[$album_id]);
            update_option('neoalbum_albums', $albums);
            wp_send_json_success(array('message' => __('Album deleted successfully!', 'neoalbum')));
        }

        wp_send_json_error(array('message' => __('Album not found', 'neoalbum')));
    }
}

NeoAlbum_Admin::get_instance();
